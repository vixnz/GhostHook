---
name: Security Research Question
about: Ask questions about cybersecurity research methods or findings
title: '[RESEARCH] '
labels: ['question', 'research', 'security']
assignees: ''
---

## Research Question
**What cybersecurity research question do you have?**

## Context and Background
**Provide context for your research question**

## Research Area
**Which area of cybersecurity does this relate to?**
- [ ] Malware analysis and detection
- [ ] Network security and monitoring
- [ ] System hardening and configuration
- [ ] Incident response and forensics
- [ ] Vulnerability assessment
- [ ] Red team methodologies
- [ ] Blue team defense strategies
- [ ] Threat intelligence
- [ ] Other: _______________

## Current Understanding
**What do you already know about this topic?**

## Specific Questions
**List your specific questions**
1. 
2. 
3. 

## Research Environment
**Describe your research/learning environment**
- [ ] Academic institution
- [ ] Corporate security team
- [ ] Independent research
- [ ] Training program
- [ ] Certification preparation

## Resources Consulted
**What resources have you already checked?**
- [ ] Academic papers and journals
- [ ] Industry documentation
- [ ] Security frameworks and standards
- [ ] Online courses and tutorials
- [ ] Conference presentations
- [ ] Professional training materials

## Expected Application
**How will you use this knowledge?**
- [ ] Academic research project
- [ ] Thesis or dissertation
- [ ] Professional development
- [ ] Security improvement initiative
- [ ] Training curriculum development
- [ ] Conference presentation

## Ethical Research Commitment
- [ ] Research is for legitimate educational/defensive purposes
- [ ] Will follow responsible disclosure practices
- [ ] Have proper authorization for any testing
- [ ] Will comply with applicable laws and policies

## Additional Information
**Any additional context that would help answer your question**

---

**Research Ethics Acknowledgment**
By submitting this question, I confirm my research is for legitimate educational and defensive security purposes, conducted under proper authorization and in compliance with applicable laws and ethical guidelines.