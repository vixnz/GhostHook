---
name: Security Vulnerability Report
about: Report a security vulnerability in the educational framework (Private First!)
title: '[SECURITY] '
labels: ['security', 'vulnerability']
assignees: ''
---

⚠️ **PLEASE READ BEFORE SUBMITTING** ⚠️

**For actual security vulnerabilities, please email security@research-framework.edu instead of creating a public issue.**

This template is for:
- Framework bugs that don't pose security risks
- Safety mechanism improvements  
- Educational content security reviews

---

## Issue Type
- [ ] Framework bug (non-security)
- [ ] Safety mechanism improvement
- [ ] Educational content review
- [ ] Documentation security review

## Issue Description
**Describe the issue clearly**

## Educational Impact
**How does this affect the educational value or safety?**

## Affected Components
**Which parts of the framework are affected?**
- [ ] Documentation
- [ ] Training materials
- [ ] Safety mechanisms
- [ ] Build system
- [ ] Automation scripts

## Steps to Reproduce
**If applicable, provide steps to reproduce the issue**
1. 
2. 
3. 

## Expected Behavior
**What should happen instead?**

## Proposed Solution
**If you have suggestions for improvement**

## Educational Environment
**Describe where you encountered this issue**
- [ ] Classroom/lab setting
- [ ] Personal study environment
- [ ] Research project
- [ ] Training exercise

## Safety Considerations
- [ ] Issue affects educational safety mechanisms
- [ ] Could impact misuse prevention
- [ ] Relates to legal compliance
- [ ] Affects authorization checking

## Additional Context
**Screenshots, logs, or other relevant information**

---

**Educational Use Confirmation**
By submitting this issue, I confirm I am using this framework for legitimate educational purposes under proper authorization and in compliance with applicable laws.